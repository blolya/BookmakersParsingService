# BookmakersParsingService
Service that provides interface for parsing betting factors.
