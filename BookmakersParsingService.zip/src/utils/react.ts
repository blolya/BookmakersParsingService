import {EventEmitter} from "events";


export class Flowable extends EventEmitter {}
